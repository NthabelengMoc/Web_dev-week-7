// DOM Elements
const themeSelect = document.getElementById('theme');
const animationSpeed = document.getElementById('animation-speed');
const animatedBox = document.querySelector('.animated-box');
const animateBtn = document.querySelector('.animate-btn');

// Load saved preferences from localStorage
function loadPreferences() {
    const savedTheme = localStorage.getItem('theme') || 'light';
    const savedSpeed = localStorage.getItem('animationSpeed') || '1';
    
    themeSelect.value = savedTheme;
    animationSpeed.value = savedSpeed;
    
    applyTheme(savedTheme);
    applyAnimationSpeed(savedSpeed);
}

// Save preferences to localStorage
function savePreferences(key, value) {
    localStorage.setItem(key, value);
}

// Apply theme
function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
}

// Apply animation speed
function applyAnimationSpeed(speed) {
    // Update CSS variable for transitions
    document.documentElement.style.setProperty('--transition-speed', `${speed}s`);
    
    // Update animation durations directly
    const bounceDuration = `${1 * speed}s`;
    const rotateDuration = `${2 * speed}s`;
    
    // Apply to animation classes
    const style = document.createElement('style');
    style.textContent = `
        .bounce {
            animation: bounce ${bounceDuration} infinite;
        }
        .rotate {
            animation: rotate ${rotateDuration} linear infinite;
        }
    `;
    
    // Remove any existing animation style element
    const existingStyle = document.getElementById('animation-speed-style');
    if (existingStyle) {
        existingStyle.remove();
    }
    
    // Add the new style element
    style.id = 'animation-speed-style';
    document.head.appendChild(style);
}

// Toggle animation classes
function toggleAnimation() {
    animatedBox.classList.toggle('bounce');
    animatedBox.classList.toggle('rotate');
}

// Event Listeners
themeSelect.addEventListener('change', (e) => {
    const theme = e.target.value;
    applyTheme(theme);
    savePreferences('theme', theme);
});

animationSpeed.addEventListener('input', (e) => {
    const speed = e.target.value;
    applyAnimationSpeed(speed);
    savePreferences('animationSpeed', speed);
});

animateBtn.addEventListener('click', toggleAnimation);

// Initialize
document.addEventListener('DOMContentLoaded', loadPreferences); 